<!-- Bopimo top and bottom -->
<div style='width:100%;padding-bottom:10px;text-align:center;'>
<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js"></script>
<!-- Horizontal -->
<ins class="adsbygoogle"
     style="display:inline-block;width:728px;height:90px"
     data-ad-client="ca-pub-6691594709216274"
     data-ad-slot="2221601403"></ins>
<script>
     (adsbygoogle = window.adsbygoogle || []).push({});
</script>
</div>
</div></div></div>
<div class="footer">
  <div style="margin-left:20%;width:60%;float:left;">
    <span style="float:left;"><img src="https://www.bopimo.com/images/logo.png" height="100"></span>
    <span style="float:right;color:#CCCCCC;">
      <ul style="list-style-type: none;float:left;">
        <li><a href="#" style="text-decoration:none;color:#CCCCCC;">About Us</a></li>
        <li><a href="/privacy/" style="text-decoration:none;color:#CCCCCC;">Privacy</a></li>
        <li><a href="#" style="text-decoration:none;color:#CCCCCC;">Staff</a></li>
      </ul>
      <ul style="list-style-type: none;float:left;">
        <li><a href="https://discord.gg/TAWXxjn" style="text-decoration:none;color:#CCCCCC;">Discord</a></li>
        <li><a href="https://twitter.com/bopimogame" style="text-decoration:none;color:#CCCCCC;">Twitter</a></li>
        <li><a href="https://www.youtube.com/channel/UC1oTIUqFMaXZKrhxQpfc95A" style="text-decoration:none;color:#CCCCCC;">Youtube</a></li>
      </ul>
    </span>
  </div>
</div>
</html>
