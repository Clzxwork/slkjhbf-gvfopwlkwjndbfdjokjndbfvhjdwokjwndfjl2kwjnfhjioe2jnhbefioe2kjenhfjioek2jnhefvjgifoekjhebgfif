<?php
echo metaphone("gas the jews");
?>