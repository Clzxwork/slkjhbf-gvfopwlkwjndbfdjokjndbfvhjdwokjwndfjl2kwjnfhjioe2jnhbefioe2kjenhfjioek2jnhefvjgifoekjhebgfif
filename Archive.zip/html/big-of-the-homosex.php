<?php

error_reporting(E_ALL); ini_set('display_errors', 1);
require "site/header.php";

?>
<div class="col-1-1">
	<div class="banner danger">
		You are gay <a class="banner-x" href="javascript: void(0);">&#10060;</a>
	</div>
</div>
<div class="content">
	<div class="row" style="width: 100%">
		<div class="col-6-12">
			<div class="card">
				Hello gay man
			</div>
			<div class="card b">
				<div class="top">
					Big of homosex?
				</div>
				<div class="body">
					Quite Possibly
				</div>
			</div>
		</div>

		<div class="col-6-12">
			<div class="card b">
				<div class="top">
					maybe im gay?
				</div>
				<div class="body">
					<a href="#"><div class="button warning">Button</div></a>
					<br>
					<input type="text" class="text-input auto">
				</div>
			</div>
		</div>
	</div>
</div>

<?php 
require "site/footer.php";
?>