<?php
include "/var/www/vernium.net/site/header.php";


?>
<center>
<h1> KAT WEDDING YAYAYA WOOO </h1>
</center>


<div class="card border">
  <div class="item-name offsale disabled">
    Story that is our's
  </div>
  It was a calm night at the Bruce strip club when i looked over at the bar and saw her. she looked so beautiful that night  and even looking at her made me nervous. oh and next to her was kat who at the time dint impress me but as the original girl denied me it became more clear that kat was truly the one i was in love with. After that we got drunk and now we are somehow here.
</div>
  <div class="item-name offsale disabled">
    picture
  </div>
  <div class="col-1-1">
    <img src="https://cdn.discordapp.com/attachments/547630852633264145/592622248544960522/EeEeEe.png" class="image">
  </div>
</div>
<?php
include "/var/www/vernium.net/site/footer.php";
?>
