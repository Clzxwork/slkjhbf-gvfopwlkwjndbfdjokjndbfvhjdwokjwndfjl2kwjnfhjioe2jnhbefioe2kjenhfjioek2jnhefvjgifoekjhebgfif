<?php
require("render-class.php");

$bop->renderAvatar(1);
?>
