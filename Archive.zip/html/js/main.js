
console.log("%cSomeone tell you to paste something here? Don't do it.", "color:#d43636;font-size:15px;");
