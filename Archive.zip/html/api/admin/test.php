<?php 

require("/var/www/vernium.net/api/admin/admin.php");
 error_reporting(E_ALL); ini_set('display_errors', 1);
//var_dump($admin->log(3, 3, "approved", "item"));

?>