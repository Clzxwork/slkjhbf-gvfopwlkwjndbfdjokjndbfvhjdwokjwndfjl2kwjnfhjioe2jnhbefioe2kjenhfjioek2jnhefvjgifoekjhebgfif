<?php
include '/var/www/vernium.net/site/bopimo.php';
include '/var/www/vernium.net/site/header.php';
?>
<div class="col-1-3" style="background-color: rgba(0,0,0,0.2);">
	<div class="card b">
		<div class="top">Title</div>
		<div class="body">
			<div class="subtitle">Normal</div>
			<a href="#!" class="button success">Success</a>
			<a href="#!" class="button warning">Warning</a>
			<a href="#!" class="button danger">Danger</a>
		</div>
	</div>
</div>
<div class="col-1-3" style="background-color: rgba(0,0,0,0.2);">
	<div class="banner danger">Danger!!</div>
	<div class="banner warning">warning!!</div>
	<div class="banner success">success!!</div>
</div>
<div class="col-1-3" style="background-color: rgba(0,0,0,0.2);">
d
</div>